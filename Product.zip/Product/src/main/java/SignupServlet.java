import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class SignupServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String username = request.getParameter("username");
        String email = request.getParameter("email");
        String password = request.getParameter("password");

        SignupDAO dao = new SignupDAO();
        boolean isUserCreated = dao.createUser(username, email, password);

        if (isUserCreated) {
            // Forward to login.jsp on successful Signuppage
            request.getRequestDispatcher("login.jsp").forward(request, response);
        } else {
            // Forward back to signup.jsp with error message
            request.setAttribute("error", "Failed to create user. Please try again.");
            request.getRequestDispatcher("Signuppage.jsp").forward(request, response);
        }
    }
}
