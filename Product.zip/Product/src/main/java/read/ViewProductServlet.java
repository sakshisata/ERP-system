package read;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ViewProductServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String productIdStr = request.getParameter("productId");
        if (productIdStr != null && !productIdStr.isEmpty()) {
            int productId = Integer.parseInt(productIdStr);
            ViewProductDAO dao = new ViewProductDAO();
            ViewProductPojo product = dao.getProductById(productId);
            if (product != null) {
                request.setAttribute("product", product);
            } else {
                request.setAttribute("error", "Product not found");
            }
        } else {
            request.setAttribute("error", "Product ID is required");
        }
        request.getRequestDispatcher("viewproduct.jsp").forward(request, response);
    }
}
