import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class LoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String username = request.getParameter("username");
        String password = request.getParameter("password");

        LoginDAO dao = new LoginDAO();
        boolean isValidUser = dao.validateUser(username, password);

        if (isValidUser) {
            // Forward to home.jsp on successful login
            request.getRequestDispatcher("Homepage.jsp").forward(request, response);
        } else {
            // Forward back to login.jsp with error message
            request.setAttribute("error", "Invalid username or password");
            request.getRequestDispatcher("login.jsp").forward(request, response);
        }
    }
}
