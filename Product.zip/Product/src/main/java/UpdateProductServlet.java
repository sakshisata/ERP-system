import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class UpdateProductServlet extends HttpServlet {

    private UpdateProductDAO updateProductDAO;

    public UpdateProductServlet() {
        this.updateProductDAO = new UpdateProductDAO();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Retrieve form parameters
        String productName = request.getParameter("productname");
        String description = request.getParameter("description");
        String category = request.getParameter("category");
        double price = Double.parseDouble(request.getParameter("price"));
        int stockLevel = Integer.parseInt(request.getParameter("stockLevel"));

        // Create a new UpdateProductPojo object
        UpdateProductPojo product = new UpdateProductPojo(productName, description, category, price, stockLevel);

        // Update the product in the database
        boolean success = updateProductDAO.updateProduct(product);

        // Set the result as a request attribute
        request.setAttribute("updateSuccess", success);

        // Forward to a JSP page to display the result
        RequestDispatcher dispatcher = request.getRequestDispatcher("Updateproduct.jsp");
        dispatcher.forward(request, response);
    }
}
