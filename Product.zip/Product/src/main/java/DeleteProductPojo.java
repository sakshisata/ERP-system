public class DeleteProductPojo {
    private int productId;

    // Default constructor
    public DeleteProductPojo() {}

    // Parameterized constructor
    public DeleteProductPojo(int productId) {
        this.productId = productId;
    }

    // Getter and setter
    public int getProductId() {
        return productId;
    }

    public void setProductId(int productId) {
        this.productId = productId;
    }

    @Override
    public String toString() {
        return "DeleteProductPojo{" +
                "productId=" + productId +
                '}';
    }
}
