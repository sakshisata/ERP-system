import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class DeleteProductServlet extends HttpServlet {

    private DeleteProductDAO deleteProductDAO;

    public DeleteProductServlet() {
        this.deleteProductDAO = new DeleteProductDAO();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Retrieve the product ID from the form
        int productId = Integer.parseInt(request.getParameter("productId"));

        // Delete the product from the database
        boolean success = deleteProductDAO.deleteProduct(productId);

        // Set the result as a request attribute
        request.setAttribute("deleteSuccess", success);

        // Forward to a JSP page to display the result
        RequestDispatcher dispatcher = request.getRequestDispatcher("Deleteproduct.jsp");
        dispatcher.forward(request, response);
    }
}
