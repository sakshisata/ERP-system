

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;




public class Controller_addproduct extends HttpServlet {

	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String productName = request.getParameter("productName");
		String description = request.getParameter("description");
		String category = request.getParameter("category");
		double price = Double.parseDouble(request.getParameter("price"));
		int stockLevel = Integer.parseInt(request.getParameter("stockLevel"));

		PojoAddProduct product = new PojoAddProduct();
		product.setProductName(productName);
		product.setDescription(description);
		product.setCategory(category);
		product.setPrice(price);
		product.setStockLevel(stockLevel);

		DaoAddProduct dao = new DaoAddProduct();
		boolean success = dao.addProduct(product);

		if (success) {
			RequestDispatcher dispatcher = request.getRequestDispatcher("Homepage.jsp");
			dispatcher.forward(request, response);
		} else {
			RequestDispatcher dispatcher = request.getRequestDispatcher("Errorpage.jsp");
			dispatcher.forward(request, response);
		}
	}
}
	

	
	