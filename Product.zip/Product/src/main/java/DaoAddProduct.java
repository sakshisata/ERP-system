

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;



public class DaoAddProduct {
	private static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
	private static final String DB_URL = "jdbc:mysql://localhost:3306/product_management"; // Replace
																							// "your_database_name" with
																							// your actual database name
	private static final String USERNAME = "root";
	private static final String PASSWORD = "sakshi88";

	public boolean addProduct(PojoAddProduct product) {
		Connection conn = null;
		PreparedStatement pstmt = null;

		try {
			Class.forName(JDBC_DRIVER);
			conn = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
			String sql = "INSERT INTO products (product_name, description, category, price, stock_level) VALUES (?, ?, ?, ?, ?)";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, ((PojoAddProduct) product).getProductName());
			pstmt.setString(2, product.getDescription());
			pstmt.setString(3, product.getCategory());
			pstmt.setDouble(4, product.getPrice());
			pstmt.setInt(5, product.getStockLevel());
			pstmt.executeUpdate();
			return true; // Return true on success
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			return false; // Return false on failure
		} catch (SQLException e) {
			e.printStackTrace();
			return false; // Return false on failure
		} finally {
			try {
				if (pstmt != null)
					pstmt.close();
				if (conn != null)
					conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
}



